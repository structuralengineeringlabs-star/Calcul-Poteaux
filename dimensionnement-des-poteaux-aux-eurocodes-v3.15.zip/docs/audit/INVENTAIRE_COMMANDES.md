# Inventaire des commandes

Généré par `npm run e2e` (tests/e2e/inventaire.spec.ts) le 01/10/2026 : **202 commandes** relevées.
La colonne « Couverture » indique le ou les tests de bout en bout qui exercent la commande.

| Écran | Commandes |
|---|---|
| Rail (projet et poteaux) | 5 |
| En-tête et étapes | 4 |
| Étape 1 — Données | 83 |
| Étape 2 — Armatures | 29 |
| Étape 3 — Vérifications | 25 |
| Étape 4 — Documents | 13 |
| Panneau de résultats | 2 |
| Cartouche et réglages | 41 |

| Écran | Type | Commande | Couverture |
|---|---|---|---|
| Rail (projet et poteaux) | bouton | Renommer | projet.spec, navigation.spec, reglages.spec |
| Rail (projet et poteaux) | bouton | Nouveau | projet.spec, navigation.spec, reglages.spec |
| Rail (projet et poteaux) | bouton | Dupliquer le poteau actif | projet.spec, navigation.spec, reglages.spec |
| Rail (projet et poteaux) | bouton | Cartouche et réglages | projet.spec, navigation.spec, reglages.spec |
| Rail (projet et poteaux) | bouton | Manuel d'utilisation | projet.spec, navigation.spec, reglages.spec |
| En-tête et étapes | bouton | Données | navigation.spec, adaptatif.spec |
| En-tête et étapes | bouton | Armatures | navigation.spec, adaptatif.spec |
| En-tête et étapes | bouton | Vérifications | navigation.spec, adaptatif.spec |
| En-tête et étapes | bouton | Documents | navigation.spec, adaptatif.spec |
| Étape 1 — Données | bouton | Aide : Forme de section | donnees.spec |
| Étape 1 — Données | liste | Forme de section? | donnees.spec (boucle sur toutes les listes) |
| Étape 1 — Données | bouton | Aide : Largeur b | donnees.spec |
| Étape 1 — Données | champ number | Largeur b? | donnees.spec (boucle sur tous les champs), robustesse.spec |
| Étape 1 — Données | bouton | Aide : Hauteur h | donnees.spec |
| Étape 1 — Données | champ number | Hauteur h? | donnees.spec (boucle sur tous les champs), robustesse.spec |
| Étape 1 — Données | bouton | Aide : Hauteur libre l | donnees.spec |
| Étape 1 — Données | champ number | Hauteur libre l? | donnees.spec (boucle sur tous les champs), robustesse.spec |
| Étape 1 — Données | bouton | Aide : Structure | donnees.spec |
| Étape 1 — Données | liste | Structure? | donnees.spec (boucle sur toutes les listes) |
| Étape 1 — Données | bouton | Aide : Liaisons (β) | donnees.spec |
| Étape 1 — Données | liste | Liaisons (β)? | donnees.spec (boucle sur toutes les listes) |
| Étape 1 — Données | bouton | Aide : Béton | donnees.spec |
| Étape 1 — Données | liste | Béton? | donnees.spec (boucle sur toutes les listes) |
| Étape 1 — Données | bouton | Aide : Acier | donnees.spec |
| Étape 1 — Données | liste | Acier? | donnees.spec (boucle sur toutes les listes) |
| Étape 1 — Données | bouton | Aide : Classe d'exposition | donnees.spec |
| Étape 1 — Données | liste | Classe d'exposition? | donnees.spec (boucle sur toutes les listes) |
| Étape 1 — Données | bouton | Aide : Paramètres nationaux | donnees.spec |
| Étape 1 — Données | liste | Paramètres nationaux? | donnees.spec (boucle sur toutes les listes) |
| Étape 1 — Données | bouton | Aide : Type de sollicitation | donnees.spec |
| Étape 1 — Données | liste | Type de sollicitation? | donnees.spec (boucle sur toutes les listes) |
| Étape 1 — Données | bouton | Aide : Saisie | donnees.spec |
| Étape 1 — Données | liste | Saisie? | donnees.spec (boucle sur toutes les listes) |
| Étape 1 — Données | bouton | Aide : Permanentes G | donnees.spec |
| Étape 1 — Données | champ number | Permanentes G? | donnees.spec (boucle sur tous les champs), robustesse.spec |
| Étape 1 — Données | bouton | Aide : Exploitation Q | donnees.spec |
| Étape 1 — Données | champ number | Exploitation Q? | donnees.spec (boucle sur tous les champs), robustesse.spec |
| Étape 1 — Données | bouton | Aide : Catégorie d'usage (EN 1990, A1.1) | donnees.spec |
| Étape 1 — Données | liste | Catégorie d'usage (EN 1990, A1.1)? | donnees.spec (boucle sur toutes les listes) |
| Étape 1 — Données | bouton | Aide : ψ1 / ψ2 | donnees.spec |
| Étape 1 — Données | champ number | ψ1 / ψ2? | donnees.spec (boucle sur tous les champs), robustesse.spec |
| Étape 1 — Données | champ number | ψ1 / ψ2? | donnees.spec (boucle sur tous les champs), robustesse.spec |
| Étape 1 — Données | champ checkbox | Ajouter le poids propre du poteau | donnees.spec |
| Étape 1 — Données | bouton | Aide : Tête / pied | donnees.spec |
| Étape 1 — Données | champ number | Tête / pied? | donnees.spec (boucle sur tous les champs), robustesse.spec |
| Étape 1 — Données | champ number | Tête / pied? | donnees.spec (boucle sur tous les champs), robustesse.spec |
| Étape 1 — Données | bouton | Aide : Courbure | donnees.spec |
| Étape 1 — Données | liste | Courbure? | donnees.spec (boucle sur toutes les listes) |
| Étape 1 — Données | bouton | Aide : Tête / pied | donnees.spec |
| Étape 1 — Données | champ number | Tête / pied? | donnees.spec (boucle sur tous les champs), robustesse.spec |
| Étape 1 — Données | champ number | Tête / pied? | donnees.spec (boucle sur tous les champs), robustesse.spec |
| Étape 1 — Données | bouton | Aide : Courbure | donnees.spec |
| Étape 1 — Données | liste | Courbure? | donnees.spec (boucle sur toutes les listes) |
| Étape 1 — Données | champ checkbox | Moments dus à des charges transversales | donnees.spec |
| Étape 1 — Données | bouton | Options avancées : coefficients, fluage, longueur efficace, effort tra | donnees.spec |
| Étape 1 — Données | bouton | Aide : αcc | donnees.spec |
| Étape 1 — Données | liste | αcc? | donnees.spec (boucle sur toutes les listes) |
| Étape 1 — Données | bouton | Aide : γc / γs | donnees.spec |
| Étape 1 — Données | champ number | γc / γs? | donnees.spec (boucle sur tous les champs), robustesse.spec |
| Étape 1 — Données | champ number | γc / γs? | donnees.spec (boucle sur tous les champs), robustesse.spec |
| Étape 1 — Données | bouton | Aide : Classe structurale | donnees.spec |
| Étape 1 — Données | liste | Classe structurale? | donnees.spec (boucle sur toutes les listes) |
| Étape 1 — Données | bouton | Aide : Δcdev | donnees.spec |
| Étape 1 — Données | champ number | Δcdev? | donnees.spec (boucle sur tous les champs), robustesse.spec |
| Étape 1 — Données | bouton | Aide : Méthode | donnees.spec |
| Étape 1 — Données | liste | Méthode? | donnees.spec (boucle sur toutes les listes) |
| Étape 1 — Données | bouton | Aide : Longueur efficace | donnees.spec |
| Étape 1 — Données | liste | Longueur efficace? | donnees.spec (boucle sur toutes les listes) |
| Étape 1 — Données | bouton | Aide : Fluage φef | donnees.spec |
| Étape 1 — Données | liste | Fluage φef? | donnees.spec (boucle sur toutes les listes) |
| Étape 1 — Données | bouton | Aide : RH / t0 | donnees.spec |
| Étape 1 — Données | champ number | RH / t0? | donnees.spec (boucle sur tous les champs), robustesse.spec |
| Étape 1 — Données | champ number | RH / t0? | donnees.spec (boucle sur tous les champs), robustesse.spec |
| Étape 1 — Données | bouton | Aide : Température moyenne | donnees.spec |
| Étape 1 — Données | champ number | Température moyenne? | donnees.spec (boucle sur tous les champs), robustesse.spec |
| Étape 1 — Données | bouton | Aide : Classe de ciment | donnees.spec |
| Étape 1 — Données | liste | Classe de ciment? | donnees.spec (boucle sur toutes les listes) |
| Étape 1 — Données | bouton | Aide : VEd plan de h | donnees.spec |
| Étape 1 — Données | champ number | VEd plan de h? | donnees.spec (boucle sur tous les champs), robustesse.spec |
| Étape 1 — Données | bouton | Aide : VEd plan de b | donnees.spec |
| Étape 1 — Données | champ number | VEd plan de b? | donnees.spec (boucle sur tous les champs), robustesse.spec |
| Étape 1 — Données | bouton | Aide : TEd | donnees.spec |
| Étape 1 — Données | champ number | TEd? | donnees.spec (boucle sur tous les champs), robustesse.spec |
| Étape 1 — Données | bouton | Aide : Mqp plan de h | donnees.spec |
| Étape 1 — Données | champ number | Mqp plan de h? | donnees.spec (boucle sur tous les champs), robustesse.spec |
| Étape 1 — Données | bouton | Aide : Durée requise | donnees.spec |
| Étape 1 — Données | liste | Durée requise? | donnees.spec (boucle sur toutes les listes) |
| Étape 1 — Données | bouton | Aide : l0,fi | donnees.spec |
| Étape 1 — Données | liste | l0,fi? | donnees.spec (boucle sur toutes les listes) |
| Étape 1 — Données | bouton | Aide : μfi imposé | donnees.spec |
| Étape 1 — Données | champ number | μfi imposé? | donnees.spec (boucle sur tous les champs), robustesse.spec |
| Étape 1 — Données | bouton | Étape suivante → | donnees.spec |
| Étape 2 — Armatures | bouton | Aide : Diamètre Φl | armatures.spec |
| Étape 2 — Armatures | liste | Diamètre Φl? | armatures.spec (boucle sur toutes les listes) |
| Étape 2 — Armatures | bouton | Aide : Nombre de barres | armatures.spec |
| Étape 2 — Armatures | champ number | Nombre de barres? | armatures.spec (boucle sur tous les champs), robustesse.spec |
| Étape 2 — Armatures | bouton | Aide : As fourni / requis | armatures.spec |
| Étape 2 — Armatures | bouton | Aide : Taux d'armatures ρ | armatures.spec |
| Étape 2 — Armatures | bouton | Aide : Diamètre Φt | armatures.spec |
| Étape 2 — Armatures | liste | Diamètre Φt? | armatures.spec (boucle sur toutes les listes) |
| Étape 2 — Armatures | bouton | Aide : Espacement courant | armatures.spec |
| Étape 2 — Armatures | champ number | Espacement courant? | armatures.spec (boucle sur tous les champs), robustesse.spec |
| Étape 2 — Armatures | bouton | Aide : Abouts / recouvrements | armatures.spec |
| Étape 2 — Armatures | bouton | Aide : Nombre de cadres | armatures.spec |
| Étape 2 — Armatures | bouton | Proposer | armatures.spec |
| Étape 2 — Armatures | bouton | Ancrages et recouvrements Masquer | armatures.spec |
| Étape 2 — Armatures | bouton | Aide : Longueurs | armatures.spec |
| Étape 2 — Armatures | liste | Longueurs? | armatures.spec (boucle sur toutes les listes) |
| Étape 2 — Armatures | bouton | Aide : Adhérence | armatures.spec |
| Étape 2 — Armatures | liste | Adhérence? | armatures.spec (boucle sur toutes les listes) |
| Étape 2 — Armatures | bouton | Aide : Barres recouvertes | armatures.spec |
| Étape 2 — Armatures | champ number | Barres recouvertes? | armatures.spec (boucle sur tous les champs), robustesse.spec |
| Étape 2 — Armatures | bouton | Aide : Zones d'ancrage / recouvrement | armatures.spec |
| Étape 2 — Armatures | champ number | Zones d'ancrage / recouvrement? | armatures.spec (boucle sur tous les champs), robustesse.spec |
| Étape 2 — Armatures | champ number | Zones d'ancrage / recouvrement? | armatures.spec (boucle sur tous les champs), robustesse.spec |
| Étape 2 — Armatures | bouton | Aide : lb,rqd | armatures.spec |
| Étape 2 — Armatures | bouton | Aide : lbd (ancrage) | armatures.spec |
| Étape 2 — Armatures | bouton | Aide : l0 (recouvrement) | armatures.spec |
| Étape 2 — Armatures | bouton | Aide : Barres | armatures.spec |
| Étape 2 — Armatures | bouton | ← Étape précédente | armatures.spec |
| Étape 2 — Armatures | bouton | Étape suivante → | armatures.spec |
| Étape 3 — Vérifications | bouton | Toutes (21) | verifications.spec (dépliage de chaque ligne, filtres) |
| Étape 3 — Vérifications | bouton | À traiter (0) | verifications.spec (dépliage de chaque ligne, filtres) |
| Étape 3 — Vérifications | bouton | Résistance N-M — Flexion dans le plan de h §6.1, §3.1.7 MEd = 101,0 kN | verifications.spec (dépliage de chaque ligne, filtres) |
| Étape 3 — Vérifications | bouton | Résistance N-M — Flexion dans le plan de b §6.1, §3.1.7 MEd = 44,9 kNm | verifications.spec (dépliage de chaque ligne, filtres) |
| Étape 3 — Vérifications | bouton | Flexion déviée §5.8.9 0,82 · ≤ 1 | verifications.spec (dépliage de chaque ligne, filtres) |
| Étape 3 — Vérifications | bouton | Élancement — Flexion dans le plan de h §5.8.3 λ = 30,3 · λlim = 26,6 | verifications.spec (dépliage de chaque ligne, filtres) |
| Étape 3 — Vérifications | bouton | Élancement — Flexion dans le plan de b §5.8.3 λ = 40,4 · λlim = 16,5 | verifications.spec (dépliage de chaque ligne, filtres) |
| Étape 3 — Vérifications | bouton | Contraintes de compression §7.2 σc,qp = 6,14 MPa · ≤ 13,5 MPa | verifications.spec (dépliage de chaque ligne, filtres) |
| Étape 3 — Vérifications | bouton | Résistance au feu R60 EN 1992-1-2 §5.3.2 R = 126 min · ≥ 60 min | verifications.spec (dépliage de chaque ligne, filtres) |
| Étape 3 — Vérifications | bouton | Section minimale As,min §9.5.2(2) 8.04 cm² · ≥ 3.48 cm² | verifications.spec (dépliage de chaque ligne, filtres) |
| Étape 3 — Vérifications | bouton | Section maximale As,max (hors recouvrement) §9.5.2(3) 0.67 % · ≤ 4 % | verifications.spec (dépliage de chaque ligne, filtres) |
| Étape 3 — Vérifications | bouton | Diamètre longitudinal §9.5.2(1) Φ16 · ≥ Φ8 | verifications.spec (dépliage de chaque ligne, filtres) |
| Étape 3 — Vérifications | bouton | Nombre de barres §9.5.2(4) 4 · ≥ 4 | verifications.spec (dépliage de chaque ligne, filtres) |
| Étape 3 — Vérifications | bouton | Diamètre des cadres §9.5.3(1) Φ8 · ≥ 6 mm | verifications.spec (dépliage de chaque ligne, filtres) |
| Étape 3 — Vérifications | bouton | Espacement courant des cadres §9.5.3(3) 200 mm · ≤ 300 mm | verifications.spec (dépliage de chaque ligne, filtres) |
| Étape 3 — Vérifications | bouton | Cadres en zones d'about §9.5.3(4) s = 180 mm · sur 400 mm en tête et e | verifications.spec (dépliage de chaque ligne, filtres) |
| Étape 3 — Vérifications | bouton | Espacement libre entre barres §8.2(2) 172 mm · ≥ 25 mm (dg = 20 mm) | verifications.spec (dépliage de chaque ligne, filtres) |
| Étape 3 — Vérifications | bouton | Section d'acier dans les recouvrements §9.5.2(3) 1.34 % · ≤ 8 % | verifications.spec (dépliage de chaque ligne, filtres) |
| Étape 3 — Vérifications | bouton | Cadres dans les recouvrements §9.5.3(4) s = 180 mm · ≥ 3 cadres sur l0 | verifications.spec (dépliage de chaque ligne, filtres) |
| Étape 3 — Vérifications | bouton | Barres intermédiaires tenues §9.5.3(6) aucune · ≤ 150 mm, sinon épingl | verifications.spec (dépliage de chaque ligne, filtres) |
| Étape 3 — Vérifications | bouton | Classe de béton minimale (annexe E) Annexe E C30/37 · ≥ C30/37 en XC4 | verifications.spec (dépliage de chaque ligne, filtres) |
| Étape 3 — Vérifications | bouton | Second ordre : courbure / rigidité — Flexion dans le plan de h §5.8.7, | verifications.spec (dépliage de chaque ligne, filtres) |
| Étape 3 — Vérifications | bouton | Second ordre : courbure / rigidité — Flexion dans le plan de b §5.8.7, | verifications.spec (dépliage de chaque ligne, filtres) |
| Étape 3 — Vérifications | bouton | ← Étape précédente | verifications.spec (dépliage de chaque ligne, filtres) |
| Étape 3 — Vérifications | bouton | Étape suivante → | verifications.spec (dépliage de chaque ligne, filtres) |
| Étape 4 — Documents | bouton | Aide : Contenu | documents.spec |
| Étape 4 — Documents | liste | Contenu? | documents.spec |
| Étape 4 — Documents | bouton | Télécharger la note (PDF) | documents.spec |
| Étape 4 — Documents | bouton | Plans A3 (PDF) | documents.spec |
| Étape 4 — Documents | bouton | Aperçu à l'écran | documents.spec |
| Étape 4 — Documents | bouton | DXF | documents.spec |
| Étape 4 — Documents | bouton | SVG | documents.spec |
| Étape 4 — Documents | bouton | DXF + logo (ZIP) | documents.spec |
| Étape 4 — Documents | bouton | Enregistrer | documents.spec |
| Étape 4 — Documents | bouton | Ouvrir | documents.spec |
| Étape 4 — Documents | champ file | .json,application/json | documents.spec |
| Étape 4 — Documents | bouton | Exporter en CSV | documents.spec |
| Étape 4 — Documents | bouton | ← Étape précédente | documents.spec |
| Panneau de résultats | bouton | Note (PDF) | verifications.spec, adaptatif.spec |
| Panneau de résultats | bouton | Plan DXF | verifications.spec, adaptatif.spec |
| Cartouche et réglages | bouton | Aide : Raison sociale | reglages.spec |
| Cartouche et réglages | champ text | Raison sociale? | reglages.spec |
| Cartouche et réglages | champ text | Adresse | reglages.spec |
| Cartouche et réglages | champ text | Téléphone | reglages.spec |
| Cartouche et réglages | champ text | Courriel | reglages.spec |
| Cartouche et réglages | bouton | Aide : Copyright | reglages.spec |
| Cartouche et réglages | champ text | Copyright? | reglages.spec |
| Cartouche et réglages | bouton | Choisir un autre logo… | reglages.spec |
| Cartouche et réglages | champ file | Afficher le logo sur la note | reglages.spec |
| Cartouche et réglages | champ checkbox | Afficher le logo sur la note | reglages.spec |
| Cartouche et réglages | champ text | Projet | reglages.spec |
| Cartouche et réglages | champ text | Client / maître d'ouvrage | reglages.spec |
| Cartouche et réglages | bouton | Aide : Référence du document | reglages.spec |
| Cartouche et réglages | champ text | Référence du document? | reglages.spec |
| Cartouche et réglages | champ text | Titre de la note | reglages.spec |
| Cartouche et réglages | bouton | Aide : Sous-titre du cartouche | reglages.spec |
| Cartouche et réglages | champ text | Sous-titre du cartouche? | reglages.spec |
| Cartouche et réglages | champ text | Date d'édition | reglages.spec |
| Cartouche et réglages | bouton | Aide : Indice de révision | reglages.spec |
| Cartouche et réglages | champ text | Indice de révision? | reglages.spec |
| Cartouche et réglages | bouton | Aide : Établi par | reglages.spec |
| Cartouche et réglages | champ text | Établi par? | reglages.spec |
| Cartouche et réglages | bouton | Aide : Vérifié par | reglages.spec |
| Cartouche et réglages | champ text | Vérifié par? | reglages.spec |
| Cartouche et réglages | bouton | Aide : Approuvé par | reglages.spec |
| Cartouche et réglages | champ text | Approuvé par? | reglages.spec |
| Cartouche et réglages | zone de texte | Afficher le logo sur la note | reglages.spec |
| Cartouche et réglages | bouton | + Ajouter une révision | reglages.spec |
| Cartouche et réglages | champ text | — | reglages.spec |
| Cartouche et réglages | champ text | — | reglages.spec |
| Cartouche et réglages | champ text | — | reglages.spec |
| Cartouche et réglages | champ text | — | reglages.spec |
| Cartouche et réglages | bouton | Supprimer | reglages.spec |
| Cartouche et réglages | bouton | Identité S.E.L. | reglages.spec |
| Cartouche et réglages | bouton | Enregistrer comme modèle | reglages.spec |
| Cartouche et réglages | bouton | Appliquer le modèle | reglages.spec |
| Cartouche et réglages | bouton | Exporter | reglages.spec |
| Cartouche et réglages | bouton | Importer | reglages.spec |
| Cartouche et réglages | champ file | Afficher le logo sur la note | reglages.spec |
| Cartouche et réglages | bouton | Télécharger le rapport | reglages.spec |
| Cartouche et réglages | bouton | Vider le journal | reglages.spec |
