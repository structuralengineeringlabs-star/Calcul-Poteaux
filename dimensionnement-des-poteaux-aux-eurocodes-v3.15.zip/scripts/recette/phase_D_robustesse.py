import asyncio, json
from playwright.async_api import async_playwright
R=[]
def ok(n,c,e=''): R.append((n,bool(c),e))
URL='http://localhost:4173'
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(); ctx=await b.new_context(viewport={'width':1366,'height':768}, accept_downloads=True); pg=await ctx.new_page()
        errs=[]; pg.on('pageerror', lambda e: errs.append(str(e)))
        await pg.goto(URL); await pg.wait_for_timeout(800)
        v1={"format":"poteaux-ec2","version":1,"info":{"projet":"Ancien"},"columns":[{"id":"a","name":"P1","materials":{"fck":30,"fyk":500,"exposureClass":"XC4","structuralClass":"S4","deltaCdev":5},"geometry":{"shape":"rect","params":{"b":30,"h":40},"L":3.5,"beta":1},"loads":{"solicitationType":"flexion_composee","NEd":1500,"MEd_user":80},"rebar":{"phiL":16,"nBars":4,"phiW":8,"spacing":200},"fire":{"R":60,"l0fiFactor":0.7}}]}
        await pg.evaluate(f"localStorage.clear(); localStorage.setItem('poteaux-ec2-projet-v1', {json.dumps(json.dumps(v1))})"); await pg.reload(); await pg.wait_for_timeout(1500)
        ok('D1 ancien projet : bandeau de mise à jour affiché', await pg.locator('text=Projet mis à jour depuis une version antérieure').count() == 1)
        ok('D2 sauvegarde de l\'original conservée', await pg.evaluate("localStorage.getItem('poteaux-ec2-projet-sauvegarde') !== null"))
        saved = json.loads(await pg.evaluate("localStorage.getItem('poteaux-ec2-projet-v1')"))
        ok('D3 projet réenregistré au format 2', saved['version'] == 2 and saved['columns'][0]['loads']['Mh_top'] == 80)
        await pg.screenshot(path='/home/claude/accD1.png')
        await pg.get_by_role('button', name='Fermer').click(); await pg.wait_for_timeout(300)
        ok('D4 bandeau refermable', await pg.locator('text=Projet mis à jour').count() == 0)
        await pg.evaluate("localStorage.setItem('poteaux-ec2-projet-v1', '{ceci n est pas du JSON')"); await pg.reload(); await pg.wait_for_timeout(1500)
        ok('D5 stockage corrompu : pas de plantage, nouveau projet et message', await pg.locator('text=était illisible').count() == 1 and await pg.locator('text=Conforme').count() >= 1)
        # rapport de diagnostic
        await pg.get_by_role('button', name='Cartouche et réglages').click(); await pg.wait_for_timeout(400)
        async with pg.expect_download() as dl: await pg.get_by_role('button', name='Télécharger le rapport').click()
        d = await dl.value; path = await d.path(); rep = json.load(open(path))
        ok('D6 rapport : version, navigateur, journal', rep['version'] and 'userAgent' in rep['navigateur'] and any('illisible' in e['msg'] for e in rep['journal']), f"{len(rep['journal'])} entrées")
        # fenêtre bloquée : repli par téléchargement
        await pg.get_by_role('button', name='← Retour au calcul').click(); await pg.get_by_role('button', name='Documents').first.click(); await pg.wait_for_timeout(300)
        await pg.evaluate("window.open = () => null")
        async with pg.expect_download(timeout=15000) as dl2: await pg.get_by_role('button', name='Générer la note').click()
        d2 = await dl2.value
        ok('D7 fenêtre bloquée : note téléchargée en HTML', d2.suggested_filename.endswith('.html'), d2.suggested_filename)
        ok('D8 journal : blocage enregistré', await pg.evaluate("JSON.parse(localStorage.getItem('poteaux-ec2-journal')).some(e => e.msg.includes('bloquée'))"))
        ok('Aucune erreur JavaScript', not errs, str(errs[:2]))
        await b.close()
asyncio.run(main())
for n,c,e in R: print(('✅' if c else '❌'), n, e)
