# Scripts de recette dans le navigateur

Vérifient les critères d'acceptation des phases A (panneaux repliables) et D (robustesse)
sur un écran de portable 1366 × 768.

Prérequis : Python 3 et Playwright (`pip install playwright && playwright install chromium`).

```
npm run build
npx vite preview          # sert l'application sur http://localhost:4173
python scripts/recette/phase_A_panneaux.py
python scripts/recette/phase_D_robustesse.py
```

Chaque critère s'affiche avec ✅ ou ❌. Ces scripts seront remplacés par la suite de tests de
bout en bout de la phase B (`npm run e2e`).
