import asyncio, json
from playwright.async_api import async_playwright
R=[]
def ok(name, cond, extra=''): R.append((name, bool(cond), extra))
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(); ctx=await b.new_context(viewport={'width':1366,'height':768}, accept_downloads=True); pg=await ctx.new_page()
        errs=[]; pg.on('pageerror', lambda e: errs.append(str(e)))
        await pg.goto('http://localhost:4173'); await pg.wait_for_timeout(1500)
        btn = pg.locator('button[aria-controls="options-avancees-contenu"]')
        ok('A1 résumé visible bouton fermé', await pg.locator('text=2nd ordre : courbure nominale').count() == 1)
        ok('A2 libellé « Afficher » et aria-expanded=false', (await btn.inner_text()).strip().endswith('Afficher') and await btn.get_attribute('aria-expanded') == 'false')
        await btn.click(); await pg.wait_for_timeout(900)
        top = await pg.evaluate("(() => { const r=[...document.querySelectorAll('#options-avancees-contenu h3')][0].getBoundingClientRect(); return [r.top, innerHeight] })()")
        ok('A3 défilement : premier réglage visible après clic (1366×768)', 0 <= top[0] < top[1] - 60, f'haut du 1er bloc = {top[0]:.0f} px / {top[1]}')
        ok('A4 libellé « Masquer » et aria-expanded=true', (await btn.inner_text()).strip().endswith('Masquer') and await btn.get_attribute('aria-expanded') == 'true')
        await pg.get_by_role('button', name='Armatures').first.click(); await pg.wait_for_timeout(300)
        await pg.get_by_role('button', name='Données').first.click(); await pg.wait_for_timeout(300)
        ok('A5 état conservé en changeant d\'étape', await pg.locator('#options-avancees-contenu').count() == 1)
        await pg.reload(); await pg.wait_for_timeout(1200)
        ok('A6 état conservé après rechargement', await pg.locator('#options-avancees-contenu').count() == 1)
        await btn.focus(); await pg.keyboard.press('Enter'); await pg.wait_for_timeout(300)
        closed = await pg.locator('#options-avancees-contenu').count() == 0
        await pg.keyboard.press('Space'); await pg.wait_for_timeout(300)
        ok('A7 clavier : Entrée ferme, Espace rouvre', closed and await pg.locator('#options-avancees-contenu').count() == 1)
        await pg.keyboard.press('Enter'); await pg.wait_for_timeout(300)  # refermer
        # A8 erreur dans un réglage avancé : γc = 0,5 injectée par le stockage du navigateur
        data = json.loads(await pg.evaluate("localStorage.getItem('poteaux-ec2-projet-v1')"))
        data['columns'][0]['materials']['gammaC'] = 0.5
        await pg.evaluate(f"localStorage.setItem('poteaux-ec2-projet-v1', {json.dumps(json.dumps(data))})"); await pg.reload(); await pg.wait_for_timeout(1500)
        ok('A8 erreur avancée : ouverture automatique + « À corriger »', await pg.locator('#options-avancees-contenu').count() == 1 and await pg.locator('text=À corriger').count() >= 1)
        await pg.screenshot(path='/home/claude/accA8.png')
        data['columns'][0]['materials']['gammaC'] = 1.5; data['columns'][0]['materials']['alphaCC'] = 0.85
        await pg.evaluate(f"localStorage.setItem('poteaux-ec2-projet-v1', {json.dumps(json.dumps(data))})"); await pg.reload(); await pg.wait_for_timeout(1200)
        ok('A9 compteur de réglages modifiés', await pg.locator('text=/1 réglage modifié/').count() == 1)
        # A10 panneau Ancrages
        await pg.get_by_role('button', name='Armatures').first.click(); await pg.wait_for_timeout(300)
        ab = pg.locator('button[aria-controls="ancrages-contenu"]')
        s_ok = await pg.locator('text=/lbd .* mm · l0/').count() == 1
        await ab.click(); await pg.wait_for_timeout(800)
        ok('A10 panneau Ancrages : résumé, ouverture, aria', s_ok and await ab.get_attribute('aria-expanded') == 'true' and await pg.locator('#ancrages-contenu').count() == 1)
        ok('Aucune erreur JavaScript', not errs, str(errs[:2]))
        await b.close()
asyncio.run(main())
for n,c,e in R: print(('✅' if c else '❌'), n, e)
